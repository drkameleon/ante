var searchData=
[
  ['obj_5fbindings',['obj_bindings',['../structante_1_1FuncDecl.html#aba983b2a4a5b5bb2353a3ce74fc295be',1,'ante::FuncDecl']]],
  ['on_5ffn_5fdecl_5fhook',['on_fn_decl_hook',['../structante_1_1CompilerCtCtxt.html#a4e7bcb70cefe9483ee4f3ca8dc604c3a',1,'ante::CompilerCtCtxt']]]
];
