var searchData=
[
  ['datadeclnode',['DataDeclNode',['../structante_1_1parser_1_1DataDeclNode.html',1,'ante::parser']]]
];
